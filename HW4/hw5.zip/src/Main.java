import controller.Controller;
import controller.ImageController;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Scanner;

import model.ImageModel;
import model.ImageModelImpl;
import view.ImageTextView;
import view.TextView;

/**
 * The Main class.
 */
public class Main {

  /**
   * Main method that takes command line arguments.
   *
   * @param args command line arguments. Can be a script, blank to use the terminal, or the
   *             operations for the program.
   */
  public static void main(String[] args) {
    ImageModel model = new ImageModelImpl();
    ImageTextView view = new TextView(System.out);
    ImageController controller;

    switch (args.length) {
      case 0:
        controller = new Controller(new InputStreamReader(System.in), model, view);
        break;
      case 1:
        String fileContents = Main.fileInput(args);
        if (fileContents.equals("")) {
          System.out.println("File " + args[0] + " not found");
          return;
        }
        controller = new Controller(new StringReader(fileContents), model, view);
        break;
      default:
        String argsContents = Main.argsContents(args);
        System.out.println(argsContents);
        controller = new Controller(new StringReader(argsContents), model, view);
        break;
    }
    controller.execute();
  }

  private static String argsContents(String[] args) {
    StringBuilder builder = new StringBuilder();
    for (int i = 0; i < args.length; i ++) {
      builder.append((args[i]));
      if (i + 1 != args.length) {
        builder.append(" ");
      }
    }
    return builder.toString();
  }

  private static String fileInput(String[] args) {
    Scanner sc;
    String fileName = args[0];

    try {
      sc = new Scanner(new FileInputStream(fileName));
    } catch (FileNotFoundException e) {
      System.out.println("File " + fileName + "not found!");
      return "";
    }
    StringBuilder builder = new StringBuilder();
    while (sc.hasNextLine()) {
      String nextLine = sc.nextLine();
      if (nextLine.length() != 0) {
        builder.append(nextLine + System.lineSeparator());
      }
    }
    return builder.toString();
  }
}