package controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import model.ImageFileImpl;
import model.ImageModel;
import model.Pixel;

/**
 * Loads an image into the program.
 */
public class LoadCommand implements Command {

  private final String filePath;

  private final String version;

  private final List<String> validExtensions = Arrays.asList(new String[]{".ppm"});

  /**
   * Constructs an instance of a LoadCommand.
   *
   * @param filePath the path of the file to be loaded
   * @param version the reference of the image
   * @throws IllegalArgumentException if any parameter is null
   */
  public LoadCommand(String filePath, String version) throws IllegalArgumentException {
    if (filePath == null || version == null) {
      throw new IllegalArgumentException("Values must not be null!");
    }

    this.filePath = filePath;
    this.version = version;
  }

  /**
   * Loads an image.
   *
   * @param model the model housing program functionality
   * @throws IllegalArgumentException if the model is null
   *                                  if the file type is not supported by this program
   *                                  if the file path is invalid
   */
  public void execute(ImageModel model) throws IllegalArgumentException {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null!\n");
    }

    try {
      Scanner sc = new Scanner(new FileInputStream(this.filePath));
      if (!validateExtension(this.filePath)) {
        throw new IllegalArgumentException("Invalid file type!\n");
      }

      String token = sc.next();
      String s = sc.next();
      int width;
      int height;

      if (s.equals("#")) {
        sc.nextLine();
        width = sc.nextInt();
        height = sc.nextInt();
      }
      else {
        width = Integer.parseInt(s);
        height = sc.nextInt();
      }


      Pixel[][] image = new Pixel[height][width];
      int maxValue = sc.nextInt();
      for (int i = 0; i < height; i ++) {
        for (int j = 0; j < width; j++) {
          int r = sc.nextInt();
          int g = sc.nextInt();
          int b = sc.nextInt();
          image[i][j] = new Pixel(r, g, b, maxValue);
        }
      }

      model.load(version, new ImageFileImpl(token, height, width, maxValue, image));
    }
    catch (FileNotFoundException e) {
      throw new IllegalArgumentException("Invalid file path!\n");
    }
  }

  private boolean validateExtension(String filePath) {
    for (String ext: this.validExtensions) {
      if (filePath.endsWith(ext)) {
        return true;
      }
    }

    return false;
  }
}
