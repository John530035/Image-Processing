package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import model.ImageFile;
import model.ImageModel;

/**
 * Saves an image to a file.
 */
public class SaveCommand implements Command {
  private final String version;
  private final String fileLocation;

  /**
   * Constructs an instance of a SaveCommand.
   *
   * @param fileLocation the location to save the file
   * @param version the image to save
   * @throws IllegalArgumentException if any parameter is null
   */
  public SaveCommand(String fileLocation, String version) throws IllegalArgumentException {
    if (version == null || fileLocation == null) {
      throw new IllegalArgumentException("Values must not be null!\n");
    }
    this.version = version;
    this.fileLocation = fileLocation;
  }

  /**
   * Saves an image to a file.
   *
   * @param model the model housing program functionality
   * @throws IllegalArgumentException if the model is null
   *                                  if the image is null
   *                                  if the file path is invalid
   *                                  if writing to the file fails
   */
  public void execute(ImageModel model) throws IllegalArgumentException {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null!\n");
    }

    ImageFile image = model.findFile(this.version);

    if (image == null) {
      throw new IllegalArgumentException("Image cannot be null");
    }

    String fileInfo = image.toString();

    try {
      File myObj = new File(fileLocation);
      myObj.createNewFile();
    } catch (IOException e) {
      throw new IllegalArgumentException("Can't create file at location!\n");
    }
    try (FileWriter writer = new FileWriter(fileLocation)) {
      writer.append(fileInfo);
      writer.close();
    } catch (IOException e) {
      throw new IllegalArgumentException("Can't write to file!\n");
    }
  }
}
