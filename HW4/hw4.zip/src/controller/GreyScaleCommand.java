package controller;

import model.ImageFile;
import model.ImageModel;

/**
 * Grey scales an image.
 */
public class GreyScaleCommand implements Command {

  private final String mode;

  private final String baseVersion;

  private final String newVersion;

  /**
   * Constructs an instance of a GreyscaleCommand.
   *
   * @param mode        the mode of grey scale
   * @param baseVersion the image to be edited
   * @param newVersion  the new reference for the image
   * @throws IllegalArgumentException if any parameter is null
   */
  GreyScaleCommand(String mode, String baseVersion, String newVersion)
      throws IllegalArgumentException {
    if (mode == null || baseVersion == null || newVersion == null) {
      throw new IllegalArgumentException("Values must not be null!");
    }
    this.mode = mode;
    this.baseVersion = baseVersion;
    this.newVersion = newVersion;
  }

  /**
   * Grey scales the image.
   *
   * @param model the model housing program functionality
   * @throws IllegalArgumentException if the model is null if the model has no image with the given
   *                                  name
   */
  @Override
  public void execute(ImageModel model) throws IllegalArgumentException {
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null!");
    }
    ImageFile image = model.greyScale(this.mode, this.baseVersion);
    model.load(this.newVersion, image);
  }
}
