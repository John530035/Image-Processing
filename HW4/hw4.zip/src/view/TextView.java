package view;

import java.io.IOException;

/**
 * TextView implementation. Outputs program information in text format.
 */
public class TextView implements ImageTextView {

  private Appendable out;

  /**
   * Constructs an instance of a TextView.
   *
   * @param out the appendable through which text will be outputted
   * @throws IllegalArgumentException if the given appendable is null
   */
  public TextView(Appendable out) throws IllegalArgumentException {
    if (out == null) {
      throw new IllegalArgumentException("Values must not be null!");
    }

    this.out = out;
  }

  /**
   * Outputs information through System.out.
   */
  public TextView() {
    this(System.out);
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.out.append(message);
  }
}
