package view;

import java.io.IOException;

/**
 * Outputs program information to the user in text format.
 */
public interface ImageTextView {

  /**
   * Outputs the given message.
   *
   * @param message the message to be outputted
   * @throws IOException if transmission to an appendable fails
   */
  void renderMessage(String message) throws IOException;
}
