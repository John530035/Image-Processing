package model;

/**
 * Represents a modifiable digital image file. The file can be converted to a String, greyscaled,
 * flipped, brightened.
 */
public interface ImageFile {

  /**
   * Formats and returns the contents of this ImageFile.
   * Includes the file type, dimensions, maximum RGB value, and
   * the RGB values of each pixel.
   *
   * @return formatted contents of this ImageFile
   */
  @Override
  String toString();

  /**
   * Greyscales this ImageFile.
   * The way
   *
   * @param mode the grey scale mode
   * @return a new ImageFile whose pixels have been greyscaled
   */
  ImageFile greyScale(String mode);

  /**
   * Flips this ImageFile horizontally.
   *
   * @return a new ImageFile that is the horizontally flipped version of this ImageFile
   */
  ImageFile horizontalFlip();

  /**
   * Flips this image vertically.
   *
   * @returna new ImageFile that is the vertically flipped version of this ImageFile
   */
  ImageFile verticalFlip();

  /**
   * Brightens or darkens this ImageFile.
   *
   * @param increment the number to increase or decrease the RGB value by
   * @return a new ImageFile that is brightened or darkened version of this ImageFile
   */
  ImageFile brighten(int increment);
}
