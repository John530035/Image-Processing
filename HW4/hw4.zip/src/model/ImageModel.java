package model;

/**
 * Represents an ImageModel.
 */
public interface ImageModel {

  /**
   * Loads the given file image into the program and associates it with the given version name.
   *
   * @param version the name which this given image file will be associated with
   * @param image the image being loaded into the program
   */
  void load(String version, ImageFile image);

  /**
   * Returns the image associated with the given version name.
   *
   * @param version the name of the image to be returned
   * @return the image assocoated with the given version name
   * @throws IllegalArgumentException if the program does not have an image associated with
   *                                  the given name
   */
  ImageFile findFile(String version) throws IllegalArgumentException;

  /**
   * Greyscales the image associated with the give version using the given mode.
   *
   * @param mode the kind of greyscale to be performed
   * @param baseVersion the name of the image to be greyscaled
   * @return  a new image that has been greyscaled
   * @throws IllegalArgumentException if the program does not have an image associated with
   *                                  the given name
   */
  ImageFile greyScale(String mode, String baseVersion) throws IllegalArgumentException;

  /**
   * Flips the image associated with the given name along the vertical axis.
   *
   * @param baseVersion the name of the image to be flipped
   * @return a new image that has been flipped horizontally
   * @throws IllegalArgumentException if the program does not have an image associated with
   *                                  the given name
   */
  ImageFile horizontalFlip(String baseVersion) throws IllegalArgumentException;

  /**
   * Flips the image associated with the given name along the horizontal axis.
   *
   * @param baseVersion the name of the image to be flipped
   * @return an new image that has been flipped vertically
   * @throws IllegalArgumentException if the program does not have an image associated with
   *                                  the given name
   */
  ImageFile verticalFlip(String baseVersion) throws IllegalArgumentException;

  /**
   * Brightens or darkens the image associated with the given name/version.
   *
   * @param baseVersion the name of the photo to be brightened/darkened
   * @param increment the value by which to brighten or darken this image
   *                  positive value to brighten the image
   *                  negative value to darkend the image
   * @return a new image that has been brightened/darkened
   * @throws IllegalArgumentException if the program does not have an image associated with
   *                                  the given name
   */
  ImageFile brighten(String baseVersion, int increment) throws IllegalArgumentException;
}
