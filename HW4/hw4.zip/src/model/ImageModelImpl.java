package model;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents an ImageModel.
 */
public class ImageModelImpl implements ImageModel {

  private final Map<String, ImageFile> versions;

  /**
   * Constructs an instance of an ImageModelImpl.
   */
  public ImageModelImpl() {
    this.versions = new HashMap<>();
  }

  @Override
  public void load(String version, ImageFile image) {
    if (this.versions.containsKey(version)) {
      this.versions.replace(version, image);
    }
    else {
      this.versions.put(version, image);
    }
  }

  @Override
  public ImageFile findFile(String version) throws IllegalArgumentException {
    if (!this.versions.containsKey(version)) {
      throw new IllegalArgumentException("Version not found!\n");
    }

    return this.versions.get(version);
  }

  @Override
  public ImageFile greyScale(String mode, String baseVersion) throws IllegalArgumentException {
    return this.findFile(baseVersion).greyScale(mode);
  }

  @Override
  public ImageFile horizontalFlip(String baseVersion) throws IllegalArgumentException {
    return this.findFile(baseVersion).horizontalFlip();
  }

  @Override
  public ImageFile verticalFlip(String baseVersion) throws IllegalArgumentException {
    return this.findFile(baseVersion).verticalFlip();
  }

  @Override
  public ImageFile brighten(String baseVersion, int increment) throws IllegalArgumentException {
    return this.findFile(baseVersion).brighten(increment);
  }
}
