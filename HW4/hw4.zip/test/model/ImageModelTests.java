package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Tests the methods in the ImageModelImpl class.
 */
public class ImageModelTests {

  private ImageModel model;

  private ImageFile imageFile;

  private ImageFile imageFile2;

  @Before
  public void init() {
    Pixel topLeft = new Pixel(50,100,150,255);
    Pixel topRight = new Pixel(50,100,150,255);
    Pixel bottomLeft = new Pixel(50,100,150,255);
    Pixel bottomRight = new Pixel(50,100,150,255);
    Pixel[][] pixelArray =
            new Pixel[][] {new Pixel[] {topLeft, topRight}, new Pixel[] {bottomLeft, bottomRight}};
    this.model = new ImageModelImpl();
    this.imageFile = new ImageFileImpl("P3", 2,2,255, pixelArray);
    this.imageFile2 = new ImageFileImpl("P3", 45, 32, 300, pixelArray);
  }

  @Test
  public void testValidInitialization() {
    try {
      this.model.findFile("any file name");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }
  }

  @Test
  public void testLoad() {
    this.model.load("koala", this.imageFile);
    assertEquals(this.model.findFile("koala"), this.imageFile);
    this.model.load("koala", this.imageFile2);
    assertEquals(this.model.findFile("koala"), this.imageFile2);
  }

  @Test
  public void testInvalidFindFile() {
    try {
      this.model.findFile("bad file");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }
  }

  @Test
  public void testFindFile() {
    this.model.load("koala", this.imageFile);
    assertEquals(this.imageFile, this.model.findFile("koala"));
    this.model.load("koala", this.imageFile2);
    assertEquals(this.imageFile2, this.model.findFile("koala"));
  }

  @Test
  public void testGreyScale() {
    try {
      this.model.greyScale("red", "koala");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }
    this.model.load("koala", this.imageFile);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n", this.model.greyScale("red", "koala").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.model.greyScale("green", "koala").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.model.greyScale("blue", "koala").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.model.greyScale("value", "koala").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.model.greyScale("intensity", "koala").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n", this.model.greyScale("luma", "koala").toString());
  }

  @Test
  public void testHorizontalFlip() {
    try {
      this.model.greyScale("red", "koala");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }
    Pixel topLeft = new Pixel(50, 50, 50, 255);
    Pixel bottomLeft = new Pixel(50, 50, 50, 255);
    Pixel topRight = new Pixel(100, 100, 100, 255);
    Pixel bottomRight = new Pixel(100, 100, 100, 255);
    Pixel[][] pixelArray
            = new Pixel[][]{new Pixel[]{topLeft, topRight}, new Pixel[]{bottomLeft, bottomRight}};
    this.imageFile = new ImageFileImpl("P3", 2, 2, 255, pixelArray);
    this.model.load("koala", this.imageFile);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n", this.model.horizontalFlip("koala").toString());
  }

  @Test
  public void testVerticalFlip() {
    try {
      this.model.greyScale("red", "koala");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }

    Pixel topLeft = new Pixel(50, 50, 50, 255);
    Pixel bottomLeft = new Pixel(100, 100, 100, 255);
    Pixel topRight = new Pixel(50, 50, 50, 255);
    Pixel bottomRight = new Pixel(100, 100, 100, 255);
    Pixel[][] pixelArray
            = new Pixel[][]{new Pixel[]{topLeft, topRight}, new Pixel[]{bottomLeft, bottomRight}};
    this.imageFile = new ImageFileImpl("P3", 2, 2, 255, pixelArray);
    this.model.load("koala", this.imageFile);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n", this.model.verticalFlip("koala").toString());
  }

  @Test
  public void testBrighten() {
    try {
      this.model.greyScale("red", "koala");
      fail();
    }
    catch (IllegalArgumentException e) {
      assertEquals("Version not found!\n", e.getMessage());
    }
    this.model.load("koala", this.imageFile);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n", this.model.brighten("koala", 50).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n", this.model.brighten("koala", -50).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n", this.model.brighten("koala", 500).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n", this.model.brighten("koala", -500).toString());
  }
}
