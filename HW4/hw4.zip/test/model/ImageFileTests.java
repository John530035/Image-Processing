package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

/**
 * Tests the methods in the ImageFileImpl class.
 */
public class ImageFileTests {

  Pixel topLeft;

  Pixel bottomLeft;

  Pixel topRight;

  Pixel bottomRight;

  Pixel[][] pixelArray;

  ImageFile imageFile;


  @Before
  public void init() {
    this.topLeft = new Pixel(50, 100, 150, 255);
    this.bottomLeft = new Pixel(50, 100, 150, 255);
    this.topRight = new Pixel(50, 100, 150, 255);
    this.bottomRight = new Pixel(50, 100, 150, 255);
    this.pixelArray
            = new Pixel[][]{new Pixel[]{topLeft, topRight}, new Pixel[]{bottomLeft, bottomRight}};
    this.imageFile = new ImageFileImpl("P3", 2, 2, 255, this.pixelArray);
  }

  @Test
  public void testInvalidInitialization() {
    try {
      this.imageFile = new ImageFileImpl("R4", 2, 2, 255, this.pixelArray);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("This program only processes .ppm files", e.getMessage());
    }
    try {
      this.imageFile = new ImageFileImpl("P3", -5, 2, 255, this.pixelArray);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Height of image must not be negative", e.getMessage());
    }
    try {
      this.imageFile = new ImageFileImpl("P3", 2, -2, 255, this.pixelArray);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Width of image must not be negative", e.getMessage());
    }
    try {
      this.imageFile = new ImageFileImpl("P3", 2, 2, -255, this.pixelArray);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Maximum RGB value must not be negative", e.getMessage());
    }
    try {
      this.imageFile = new ImageFileImpl("P3", 2, 2, 255, null);
      fail();
    } catch (IllegalArgumentException e) {
      assertEquals("Error processing RGB values", e.getMessage());
    }
  }

  @Test
  public void testValidInitialization() {
    assertEquals("P3\n"
            + "2 2\n"
            + "255\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n", this.imageFile.toString());
  }

  @Test
  public void testToString() {
    assertEquals("P3\n"
            + "2 2\n"
            + "255\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n"
            + "50\n"
            + "100\n"
            + "150\n", this.imageFile.toString());
  }

  @Test
  public void testGreyScaleRed() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n", this.imageFile.greyScale("red").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n", this.imageFile.greyScale("Red").toString());
  }

  @Test
  public void testGreyScaleGreen() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.imageFile.greyScale("green").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.imageFile.greyScale("Green").toString());
  }

  @Test
  public void testGreyScaleBlue() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.imageFile.greyScale("blue").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.imageFile.greyScale("Blue").toString());
  }

  @Test
  public void testGreyScaleValue() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.imageFile.greyScale("value").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n" +
            "150\n", this.imageFile.greyScale("Value").toString());
  }

  @Test
  public void testGreyScaleLuma() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n", this.imageFile.greyScale("luma").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n" +
            "92\n", this.imageFile.greyScale("luma").toString());
  }

  @Test
  public void testGreyScaleIntensity() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.imageFile.greyScale("intensity").toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n", this.imageFile.greyScale("Intensity").toString());
  }

  @Test
  public void testHorizontalFlip() {
    this.topLeft = new Pixel(50, 50, 50, 255);
    this.bottomLeft = new Pixel(50, 50, 50, 255);
    this.topRight = new Pixel(100, 100, 100, 255);
    this.bottomRight = new Pixel(100, 100, 100, 255);
    this.pixelArray
            = new Pixel[][]{new Pixel[]{topLeft, topRight}, new Pixel[]{bottomLeft, bottomRight}};
    this.imageFile = new ImageFileImpl("P3", 2, 2, 255, this.pixelArray);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n", this.imageFile.horizontalFlip().toString());
  }

  @Test
  public void testVerticalFlip() {
    this.topLeft = new Pixel(50, 50, 50, 255);
    this.bottomLeft = new Pixel(100, 100, 100, 255);
    this.topRight = new Pixel(50, 50, 50, 255);
    this.bottomRight = new Pixel(100, 100, 100, 255);
    this.pixelArray
            = new Pixel[][]{new Pixel[]{topLeft, topRight}, new Pixel[]{bottomLeft, bottomRight}};
    this.imageFile = new ImageFileImpl("P3", 2, 2, 255, this.pixelArray);
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "100\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n" +
            "50\n", this.imageFile.verticalFlip().toString());
  }

  @Test
  public void Brighten() {
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n" +
            "100\n" +
            "150\n" +
            "200\n", this.imageFile.brighten(50).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n" +
            "255\n", this.imageFile.brighten(500).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n" +
            "0\n" +
            "50\n" +
            "100\n", this.imageFile.brighten(-50).toString());
    assertEquals("P3\n" +
            "2 2\n" +
            "255\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n" +
            "0\n", this.imageFile.brighten(-500).toString());
  }
}
